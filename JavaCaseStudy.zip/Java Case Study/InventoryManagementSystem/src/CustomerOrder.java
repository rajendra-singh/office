import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class CustomerOrder {

	public static void main(String[] args) { 	
		String carStandingOrders = "C:\\Java Case Study\\carStandingOrders.csv";
		
			List carDetails =loadInventory(carStandingOrders);
			//System.out.println(carDetails);
						
			
	

		
	    }
	
	public static List loadInventory(String fileName)
	{
		List carDetails = new ArrayList();
	
	
	try(BufferedReader br = new BufferedReader(new FileReader(fileName))){
		String columnName = br.readLine();
		String[] columnValues = columnName.split(",");
		String line; 
		while((line = br.readLine()) != null) {
			Map<String, String> map = new HashMap<String, String>();
			String[] values = line.split(",");
			for( int i=0; i<columnValues.length; i++) {
				map.put(columnValues[i], values[i]);
				
			}
			double carPrice = getCarInventory(map);
			//System.out.println("carPrice : "+carPrice);
			double accesoriesPrice = carPrice!=0?getAccessoriesValue(map):0;//System.out.println(map);
			//System.out.println(accesoriesPrice);
			double taxRate = getTaxRate(map, carPrice, accesoriesPrice);
			
		}
		
	}
	catch(FileNotFoundException e) {
		e.printStackTrace();
	} 
	catch (IOException e) {
		e.printStackTrace();
	}
	return carDetails;

	}
	
	public static double getCarInventory(Map<String, String> carDetails)
	{
		
		String vendor=(String) carDetails.get("vendor");
		String model=(String) carDetails.get("model");
		String variant=(String) carDetails.get("variant");
		String color=(String) carDetails.get("color");
		
		try(BufferedReader br = new BufferedReader(new FileReader("C:\\Java Case Study\\carinventory.csv"))){
			String line; 
			while((line = br.readLine()) != null) {
				Map<String, String> map = new HashMap<String, String>();
				if(line.contains(vendor) && line.contains(model) && line.contains(variant) && line.contains(color) ) {
					//System.out.println("true");
					//System.out.println(line);
					String[] carValues = line.split(",");
					double price = Integer.parseInt(carValues[4]);
					String quantity = carValues[5];
					return price;
				}
			}
			
		}
		catch(FileNotFoundException e) {
			e.printStackTrace();
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		return 0;
				
	}
	
	public static double getAccessoriesValue(Map<String, String> accessoryDetails) {
		
		String vendor=(String) accessoryDetails.get("vendor");
		String model=(String) accessoryDetails.get("model");
		String accessoriesType=!accessoryDetails.get("accessories").equals("")?accessoryDetails.get("accessories").toString():null;
		String[] accessories = accessoriesType!=null?accessoriesType.split(":"):null;
		Map<String, String> map = new HashMap<String, String>();
		List list = new ArrayList();
		double sum =0 ;
		try(BufferedReader br = new BufferedReader(new FileReader("C:\\Java Case Study\\accessoryinventory.csv"))){
			String line;
			List fileLines= new ArrayList();
			while((line = br.readLine())!=null) {
				fileLines.add(line);
			}
				
				
//				System.out.println(line);
				for(int i=0;i<(accessories!=null?accessories.length:0);i++)
				{
					for(int j=0;j<fileLines.size();j++)
					{
						String lines = (String)fileLines.get(j);
					if(lines.contains(vendor) && lines.contains(model)) {
						String[] accessoriesValues = lines.split(",");
						String accessoryName = accessoriesValues[2];
						int price = Integer.parseInt(accessoriesValues[3]);
						String quantity = accessoriesValues[4];
						
							if(lines.contains(accessories[i].trim())) {
								sum = sum + price;  
								list.add(price);
							}
						}
					}
				}
			}
			
		
		catch(FileNotFoundException e) {
			e.printStackTrace();
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		return sum;
				

	}
	
	public static double getTaxRate(Map<String, String> taxDetails, double basePrice, double accessoriesPrice) {
		
		String requiredRegion=(String) taxDetails.get("region");
		
		try(BufferedReader br = new BufferedReader(new FileReader("C:\\Java Case Study\\regionalTaxRateConfiguration.csv"))){
			String line; 
			while((line = br.readLine()) != null) {
				String[] regionDetails = line.split(",");
				String region = regionDetails[0];
				//System.out.println(region);	
				if(requiredRegion.equalsIgnoreCase(region))
				{
					int taxRate = Integer.parseInt(regionDetails[1]);
					System.out.println(taxRate);
					double tax = (basePrice+accessoriesPrice)*taxRate;
					return tax;
				}
				/*
				 * else if(!requiredRegion.equalsIgnoreCase(region)) {
				 * 
				 * int taxRate = 0; System.out.println(taxRate);
				 * 
				 * }
				 */
				
			}
			
		}
		catch(FileNotFoundException e) {
			e.printStackTrace();
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		
		
		return 0;
		
	}
}



















