import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Inventory {

	public static void main(String[] args) {
		
		String carStandingOrders = "C:\\Java Case Study\\carStandingOrders.csv";
		List<Map<String, String>> records = loadInventory(carStandingOrders);

		for( int i =0; i<records.size(); i++) {
			System.out.println(records.get(i));
		}
		
		
	}
		public static List loadInventory(String fileName)
		{
			
			List<Map<String, String>> records = new ArrayList<Map <String, String>>();
			try(BufferedReader br = new BufferedReader(new FileReader(fileName))){
				String columnName = br.readLine();
				String[] columnValues = columnName.split(",");
				String line; 
				while((line = br.readLine()) != null) {
					Map<String, String> map = new HashMap<String, String>();
					String[] values = line.split(",");
					for( int i=0; i<columnValues.length; i++) {
						map.put(columnValues[i], values[i]);
						
					}
					records.add(map);
				}
				
			}
			catch(FileNotFoundException e) {
				e.printStackTrace();
			} 
			catch (IOException e) {
				e.printStackTrace();
			}
			
			return records;
			
		}

	}
